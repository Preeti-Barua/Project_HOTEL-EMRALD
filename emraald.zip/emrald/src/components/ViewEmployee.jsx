import React, { Component } from 'react'
import { Redirect } from 'react-router';
import EmployeeService from '../service/EmployeeService'
import Logout from './LogoutAdmin';

class ViewEmployee extends Component{
    constructor(props){
        super(props)

        const token=localStorage.getItem("token");

        let loggedin=true;

        if(token==null)
        {
            loggedin=false;
        }

        this.state={
            employees: [],
            loggedin
        }
        this.addEmployee= this.addEmployee.bind(this);
        this.editEmployee=this.editEmployee.bind(this);
        this.back=this.back.bind(this);
      
    }

    editEmployee(id){
        this.props.history.push(`/update-employee/${id}`);

    }
    addEmployee(){
        this.props.history.push('/add-employee');
    }
    back(){
        this.props.history.push('/Admin');
    }

    // checkEmployee(){
    //     this.props.history.push('/checking');
    // }
    componentDidMount(){

        EmployeeService.getEmployees().then((res) => {

            this.setState({employees: res.data});
            console.log(res.data);
        });


     }
    render()
    {
        if(this.state.loggedin=== false)
        {
            return <Redirect to="/Adminlogin"></Redirect>
        }
        return (
            <div >
                <br/>
                
                <Logout/>
                <button type="button" className="btn btn-primary" onClick={this.back} style={{marginLeft: "40px"}} >Back</button>
                <h1 className="text-center" style={{"font-family":"elephant"}}> Employees List</h1>
                <div style={{marginLeft: "40px"}}>
                <div style={{marginRight: "40px"}}>
                <div className="row">
                    <button className="btn btn-success" onClick={this.addEmployee}> Add Employee </button>
                    {/* <div className="text-center"> */}
                    <table className="table table-striped table-bordered" style={{"borderWidth":"3px", 'borderColor':"black", 'borderStyle':'solid'}} > 
                
                        <thead style={{'background-color': 'Navy',"border":"3px solid black","color":"white"}}>
                       
                           
                            <tr>
                                 {/* <th >Id </th> */}
                                <th>Govtid</th>
                                <th>Employee_Name</th>
                                <th>Occupation </th>
                                <th>Gender</th>
                                <th>Permanent_Address</th>
                                <th>Current_Address</th>
                                <th>DateOfBirth</th>
                                <th>Local_Refrence </th>
                                <th>Phone_No</th>
                                <th>Status</th>
                                <th >Actions </th>
                             
                            </tr>
                        </thead>
                        <tbody style={{'border':"3px solid black"}}>
                            {
                                this.state.employees.map(
                                    employee =>
                                    <tr key={employee.empid} style={{'background-color': 'seashell',"border":"2px solid black" }}>
                                         {/* <td>{employee.empid}</td> */}
                                        <td>{employee.govtid}</td>
                                        <td>{employee.name}</td>
                                          <td>{employee.occupation}</td>
                                          <td>{employee.gender}</td>
                                          <td>{employee.permanent_address}</td>
                                          <td>{employee.temporary_address}</td>
                                          <td>{employee.dateofbirth}</td>
                                          <td>{employee.localrefrence}</td>
                                          <td>{employee.phoneno}</td>
                                          <td>{employee.status}</td>
                                          <td>
                                              <button onClick= { () =>this.editEmployee(employee.empid)}className="btn btn-info">Update</button>
                                            
 
                                          </td>
                                          </tr>         
                                )
                            }
                            </tbody>
                            
                            </table>
                        </div>
                    </div>
                </div>
             </div>
        )
    }
}
export default ViewEmployee;