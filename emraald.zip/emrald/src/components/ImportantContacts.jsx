import React, { Component } from 'react'
import Table from "./Table";
export default class ImportantContacts extends Component {
 
    render() {
        return (
        
            <div className="text-center">
            <div className="mt-2" >
                 <h3>For Queries Please Contact</h3>
                 <Table />
            </div>
            <div classname="Address">
                       <h3><strong>Hotel Emerald</strong></h3>
                       <h4>xyz road abc address</h4>
                       </div>
            </div>
        )
       }
       
    }
    