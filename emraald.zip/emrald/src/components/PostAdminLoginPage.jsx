import React, { Component } from 'react'
import { Redirect } from 'react-router';
import Logout from './LogoutAdmin';

import v1 from "./video/v1.mp4";

export default class PostAdminLoginPage extends Component {

    constructor(props) {
        super(props)

        const token=localStorage.getItem("token");

        let loggedin=true;

        if(token==null)
        {
            loggedin=false;
        }

        this.state = {
            loggedin
        }

        this.viewEmployee = this.viewEmployee.bind(this);
        this.addEmployee = this.addEmployee.bind(this);
        this.roomInfo = this.roomInfo.bind(this);
        this.addRooms = this.addRooms.bind(this);
        this.AddRec = this.AddRec.bind(this);
        
    }

    viewEmployee()
    {
        this.props.history.push('/view-Employee');
    }

    addEmployee()
    {
        this.props.history.push('/add-Employee');
    }

    addRooms()
    {
        this.props.history.push('/add-Rooms');
    }

    roomInfo()
    {
        this.props.history.push('/Room-Info');
    }
    AddRec()
    {
        this.props.history.push('/Add-Rec');
    }
    

    render() {
        if(this.state.loggedin=== false)
        {
            return <Redirect to="/Adminlogin"></Redirect>
        }
        return (
            <div>
            <video autoPlay
          loop
          muted
          style={{
              position:"absolute",
              width:"100%",
              left:"50%",
              top:"50%",
              height:"100%",
              objectFit:"cover",
              transform:"translate(-50% ,-50%)",
              zIndex:"-1"
          }}>
         <source src={v1} type="video/mp4"/>
          </video>
            <div>

                        
            <h1 className="text-center" style={{"color":"white","font-family":"elephant"}}> Admin Page</h1>
                   
                   <Logout/>
                   
                   <br/>
                   <br/>
                    <div className="col-md-12 text-center" style={{display:'block'}}>
                   
                   <button type="button" className="btn btn-warning" onClick={this.viewEmployee} className="block">View All Employees</button><br/><br/>
                   <button type="button" className="btn btn-warning" onClick={this.addEmployee} className="block">Add Employee</button><br/><br/>
                   <button type="button" className="btn btn-warning" onClick={this.addRooms} className="block">Add rooms</button><br/><br/>
                   <button type="button" className="btn btn-warning" onClick={this.roomInfo} className="block">Room Info</button><br/><br/>
                   {/* <button type="button" className="btn btn-warning" onClick={this.AddRec} >Add Receptionist</button><br/><br/> */}
                  

                    </div>
                    </div>
                     </div>
              
                
       
           
        )
    }
}


