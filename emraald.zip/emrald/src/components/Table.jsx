import React from 'react';
//import '../src/App.css';
import * as ReactBootStrap from "react-bootstrap";

const Table = () => {
    const employees = [
        {Position:"Manager",Department:"Admin",Contactno:"9999999911"},
        {Position:"Head",Department:"Kitchen",Contactno:"9999999912"},
        {Position:"Head",Department:"Cleaning",Contactno:"9999999913"},
        {Position:"Head",Department:"Sales",Contactno:"9999999914"},
        {Position:"Technician",Department:"Civil",Contactno:"9999999911"},
        {Position:"Technician",Department:"Electrical",Contactno:"9999999912"},
        {Position:"Technician",Department:"Plumbing",Contactno:"9999999913"},
        {Position:"Fire",Department:"Emergency",Contactno:"184101"},
        {Position:"Police",Department:"Emergency",Contactno:"100"},
    ]
    const renderEmployee = (employee, index) => {
        return(
            <tr key={index} style={{"color":"white"}}>
            <td>{employee.Position}</td>
            <td>{employee.Department}</td>
            <td>{employee.Contactno}</td>
            </tr>
        )
    }
    
    return (
        <div className="Table" >
        <ReactBootStrap.Table stripped bordered hover>
            <thead style={{"color":"white"}}>
                <tr>
                    <th>Position</th>
                    <th>Department</th>
                    <th>Contactno</th>
                </tr>
            </thead>
            <tbody>
            {employees.map(renderEmployee)}
            </tbody>
        </ReactBootStrap.Table>
        </div>
    );
   
}


export default Table;