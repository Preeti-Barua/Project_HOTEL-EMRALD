import { Component } from "react"

export default class Error extends Component {

    
    

    
    render() {
    return (
    
        <div className="text-center">
        <div className="mt-5" >
             <h1>OOPS! Page Not Found</h1>
        </div>
        </div>
    )
   }
   
}