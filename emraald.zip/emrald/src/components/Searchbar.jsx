import React, { Component } from 'react'
import { Redirect } from 'react-router';
import Service from '../service/Service';
import Logout from './LogoutRec';


class MyComponent extends Component {
 
     constructor(props){
         super(props)
 
         const token=localStorage.getItem("tokenrec");
 
         let loggedin=true;
 
         if(token==null)
         {
             loggedin=false;
         }
 
         this.state={
             customers: [],
 
             status:'',
 
             
             loggedin
         }
         this.changeFirstNameHandler= this.changeFirstNameHandler.bind(this);
        //  this.editCustomer=this.editCustomer.bind(this);
 
        
       
     }
 
     changeFirstNameHandler(e){
        this.setState({nm: e.target.value});

 
         Service.getCustomerByName(this.state.nm).then((res) => {
             let c=res.data;
             console.log(c);
             this.setState({status:c.status});
             if(c.status===1)
             {
                 this.setState({customers: c.contlist});
             }
             
 
         });
 
 
      }
 
     getTitle()
     {
         if(this.state.status===0)
         {
             return <div className="text-center">No Customer Found !</div>
         }
     }
 
     render()
     {
         if(this.state.loggedin=== false)
         {
             return <Redirect to="/Receptionlogin"></Redirect>
         }
         return (

        <div>
            
        <div className="text-center"><br/>
        <input type="text"
          placeholder="Search" onChange={this.changeFirstNameHandler}/>
          {/* <br/> */}
       
        </div> <Logout/>
             {/* <div className="container"> */}
                 <div style={{marginLeft: "80px"}}>
                
             
 
 
                 <h1 className="text-center" style={{"color":"white","font-family":"elephant"}}> Customers List</h1>
                 <div className="text-warning">
                         {
                             this.getTitle()
                         }
                     </div>
                     <div style={{marginRight: "80px"}} >
                 <div className="row">
                     {/* <button className="btn btn-primary" onClick={this.addEmployee}> Add Employee </button> */}
                     {/* <div className="text-center"> */}
                     <table className="table table-bordered"  style={{"borderWidth":"3px", 'borderColor':"black", 'borderStyle':'solid'}}> 
                 
                         <thead style={{'background-color': 'Navy',"border":"3px solid black","color":"white"}}>
                            
                             <tr>
                                 {/* <th>Id</th> */}
                                 <th>GovtId</th>
                                 <th>CustomerName</th>
                                 <th>Gender</th>
                                 <th>PhoneNo</th>
                                 <th>Address</th>
                                 {/* <th>Pincode</th> */}
                                 <th>RoomNo</th>
                                 <th>CheckInDate </th>
                                 <th>CheckInTime</th>
                                 <th >CheckOutDate </th>
                                 <th>CheckOutTime</th>
                                 {/* <th>Action</th> */}
                             </tr>
                         </thead>
                         <tbody style={{'border':"3px solid black"}}>
                             {
                                 this.state.customers.map(
                                     customer =>
                                      <tr key={customer.customerid} style={{'background-color': 'seashell',"border":"2px solid black" }}   >
                                          {/* <td>{customer.customerid}</td> */}
                                         <td>{customer.govtid}</td>
                                         <td>{customer.name}</td>
                                           <td>{customer.gender}</td>
                                           <td>{customer.phone_no}</td>
                                           <td>{customer.city_address}</td>
                                           {/* <td>{customer.pincode}</td> */}
                                           <td>{customer.roomno}</td>
                                           <td>{customer.checkindate}</td>
                                           <td>{customer.checkintime}</td>
                                           <td>{customer.checkoutdate}</td>
                                           <td>{customer.checkouttime}</td>
                                           {/* <td> */}
                                               {/* <button onClick= { () =>this.editCustomer(customer.customerid)}className="btn btn-info">Update</button> */}
                                               {/* <img onClick= { () =>this.editCustomer(customer.customerid)} src="../../../images/update.jpg" style={{"width":"25%"}}></img> */}
  
                                           {/* </td> */}
                                           </tr>         
                                 )
                             }
                         </tbody>
                             
                     </table>
                     </div>
                     </div>
             </div>
              </div>
            //   </div>
         )
     }
 }
 export default MyComponent;
 