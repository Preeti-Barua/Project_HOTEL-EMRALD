//import React, { Component } from 'react'
import React from "react";
import Sdata from "./Sdata"
import Card from "./Card";
//import { render, screen } from '@testing-library/react';
import Imageslider from './Imageslider';

const Home = () => {
    return (
        <>
        <div  className="my-0">
      
        </div>
        <div className="App">
            <br/>
        <div className="navbar-nav ml-auto mb-2 mb-lg-0">
        <img src="/images/details-1.jpeg" alt="" />   
        <h2><span><span>Hotel Emrald Welcomes You</span></span></h2>
        {/* <h2><span><span>Hotel Emrald Welcomes You</span></span></h2> */}
<br/><br/><br/> 
 <h1 className="m-3 d-flex justify-content-center">GALLERY</h1> 
 

      <Imageslider />
      
    </div>
    </div>
    <br/>
    <br/>
    <br/>
    <br/>
            <div className="container-fluid mb-5">
            <div className="row">
                <div className="col-10 mx-auto">
                    <div className="row gy-4">   
                    {
                        Sdata.map((val,ind) => {
                            return <Card key={ind} imgsrc={val.imgsrc}  title={val.title}/>

                        })
                    }             

                    </div>   
                </div> 
            </div>
        </div>        
        
        </> 
    ); 
};

export default Home;
