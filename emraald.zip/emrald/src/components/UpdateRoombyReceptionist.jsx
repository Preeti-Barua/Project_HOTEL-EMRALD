import React, { Component } from 'react'
import { Redirect } from 'react-router';

import RoomService from '../service/RoomService'
import Logout from './LogoutRec';

export default class UpdateRoombyReceptionist extends Component {
    constructor(props){
        super(props) 

        const token=localStorage.getItem("tokenrec");

        let loggedin=true;

        if(token==null)
        {
            loggedin=false;
        }

        this.state={
            roomno: this.props.match.params.roomno,
            room_type:'',
            booking_status:'',
            cleaning_status:'',

            status:'',
            loggedin
 }
       // this.changeroom_typeHandler=this.changeroom_typeHandler.bind(this)
       // this.updateEmployee=this.updateEmployee.bind(this)
    }
    componentDidMount(){
        RoomService.getRoomByRoomno(this.state.roomno).then((res) =>{
            if(res.status === 200)
            {
            let R=res.data.content;
            console.log(R);
            this.setState({
                
                room_type: R.room_type,
                booking_status: R.booking_status,
                cleaning_status: R.cleaning_status
                  });
            }
            else
            {
                console.log(res);
            }
            }).catch((error) => {
                console.log(error);
                this.props.history.push('/S-D-R');
            });
    }
    updateRoom= (e) =>{
        e.preventDefault();
        let r1= {
            roomno:this.state.roomno,
            room_type:this.state.room_type,
            booking_status: this.state.booking_status,
            cleaning_status: this.state.cleaning_status
        }
            
            

            RoomService.updateRoombyReceptionist(r1).then(res =>{

            if(res.status === 200)
            {
                let c=res.data;
                console.log(c);
                this.setState({status:c.status});
                if(c.status===1)
                {
                    this.props.history.push('/show-rooms');
                }
            }
            else{
                console.log(res);
            }
            }).catch((error) => {
                console.log(error);
                this.props.history.push('/S-D-R');
            });


    }
    
    
    changebooking_statusHandler=(event)=>{
        this.setState({booking_status: event.target.value});
    }
    changecleaning_statusHandler=(event)=>{
        this.setState({cleaning_status: event.target.value});
    }


    getTitle()
    {
        if(this.state.status===0)
        {
            return <div className="text-center">Room Details could not be Updated</div>
        }
    }

    
    cancel(){
        this.props.history.push('/Reception');
    }
    render() {
        if(this.state.loggedin=== false)
        {
            return <Redirect to="/Receptionlogin"></Redirect>
        }
        return (
            <div>
                <br/>
                <Logout/>
                <br/>
                <div className="container">
                <div className="text-danger">
                        {
                            this.getTitle()
                        }
                    </div>
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3">
                            <br/>
                        <h3 className="text-center" style={{"font-family":"elephant"}}>Update Room</h3>
                        <div className="card-body">
                            <form>
                            
                                            <div className="form-group">
                                                <label>Room No</label>
                                                <input placeholder="roomno" className="form-control"
                                                value={this.state.roomno} disabled = "disabled"/>
                                            </div>
                                            <div className="form-group">
                                                <label>Room Type</label>
                                                <input placeholder="Room type" className="form-control"
                                                value={this.state.room_type} disabled = "disabled" />
                                            </div>
                                            <div className="form-group">
                                                <label>Booking Status</label>
                                                <select value={this.state.booking_status} name="booking_status" className="form-control" onChange={this.changebooking_statusHandler}>
                                             <option value="choose">choose</option>
                                                <option value="Booked">Booked</option>
                                                <option value="UnBooked">UnBooked</option>
                                             </select>
                                                {/* <input placeholder="booking status"
                                                name="booking_status" className="form-control"
                                                value={this.state.booking_status} onChange={this.changebooking_statusHandler} /> */}
                                            </div>
                                            <div className="form-group">
                                                <label>Cleaning Status</label>
                                                <select name="cleaning_status" className="form-control"
                                                value={this.state.cleaning_status} onChange={this.changecleaning_statusHandler}>
                                                     <option value="choose">Choose</option>
                                                <option value="Dirty">Dirty</option>
                                                <option value="Clean">Clean</option>
                                                </select>
                                                {/* <input placeholder="cleaning status"
                                                name="cleaning_status" className="form-control"
                                                value={this.state.cleaning_status} onChange={this.changecleaning_statusHandler} /> */}
                                            </div>

                                            <button className="btn btn-success" onClick={this.updateRoom}>Update</button>
                                            <button className="btn btn-danger" onClick={this.cancel.bind(this)}style={{marginLeft:"10px"}}>Cancel</button>
                            </form>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
    
