
import room1 from "./room1.jpeg";
import room3 from "./room3.jpeg";
import room4 from "./room4.jpeg";
import room5 from "./room5.jpeg";
import room7 from "./room7.jpeg";
import room8 from "./room8.jpeg";


const Sdata=[
    
    {
        imgsrc:room1,
        title:"Family Deluxe"
    },
    {
        imgsrc:room3,
        title:"Presidential Economy",
    },
    {
        imgsrc:room4,
        title:"Double Deluxe",
    },
    {
        imgsrc:room5,
        title:"Double Basic",
    },
    {
        imgsrc:room7,
        title:"Double Economy",
    },
    {
        imgsrc:room8,
        title:"Single Deluxe",
    },

    
];

export default Sdata;
