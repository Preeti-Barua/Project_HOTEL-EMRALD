import React, { Component } from 'react'
import {NavLink} from 'react-router-dom';
import {Navbar,Nav,NavDropdown} from 'react-bootstrap';



export default class Navigation extends Component {
    
    render() {
       
        return (
            <Navbar bg="dark" expand="lg">
                <Navbar.Toggle aria-controls="basic-navbar-nav"/>
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav>
                        <NavLink className="d-inline p-2 bg-dark text-white"
                        to="/">Home</NavLink>
                        <NavLink className="d-inline p-2 bg-dark text-white"
                        to="/contacts">Contacts </NavLink>
                      
                        <NavLink className="d-inline p-2 bg-dark text-white"
                        to="/Adminlogin">Admin</NavLink>
                          <NavLink className="d-inline p-2 bg-dark text-white"
                        to="/Receptionlogin">Reception</NavLink>
                         {/* <NavDropdown title='LogIn' id="collasible-nav-dropdown">
                          <NavDropdown.Item href="/Adminlogin">Admin</NavDropdown.Item>
                          <NavDropdown.Item href="/Receptionlogin">Reception</NavDropdown.Item>
        
                        </NavDropdown> */}
                        
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
           
        )
    }
}



