import React, { Component } from 'react'
import Service from '../service/Service';
import v2 from "./video/v2.mp4";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons/index";
import { Redirect } from 'react-router';
import {Form, Button} from 'react-bootstrap';
const eye = <FontAwesomeIcon icon={faEye} />;

export default class Adminlogin extends Component {

    constructor(props) {
        super(props)

        const token=localStorage.getItem("token");

        let loggedin=true;

        if(token===null)
        {
            
            loggedin=false;
        }
        this.state = {
            AdminId: '',
            pass: '',
            status:'',
            x:'password',
            loggedin
        }
        
        this.Postlogin = this.Postlogin.bind(this);
        this.myFunction = this.myFunction.bind(this);
    }
    

    Postlogin = (e) => {
        e.preventDefault();
       
        let ad={adminid:this.state.AdminId,password:this.state.pass};
        Service.loginadmin(ad).then(res =>{

        if(res.status === 200)
        {
            let c=res.data;
            console.log(c);
            this.setState({status:c.status});
            if(c.status===1)
            {
                localStorage.setItem("token","llookkpp");
                this.setState({loggedin:true});
                // this.props.history.push('/Admin');
            }
           
        }
        else
        {
            console.log(res);
        }
        }).catch((error) => {
            console.log(error);
            this.props.history.push('/S-D-R');
        });
    }
   

    changeAcnoHandler= (event) => {
        this.setState({AdminId: event.target.value});
    }

    changePinHandler= (event) => {
        this.setState({pass: event.target.value});
    }

    getTitle()
    {
        if(this.state.status===0)
        {
            return <div className="text-center">Login Failed, Check Your Credentials</div>
        }
    }
    cancel(){
        this.props.history.push('/');
    }
    
    myFunction() {
        
        if (this.state.x === "password") {
            this.setState({x:"text"});
        } else {
            this.setState({x:"password"});
        }
      }
    
    render() {
        if(this.state.loggedin)
        {
            return <Redirect to='/Admin'></Redirect>
        }
    return (
        <div>
        <video autoPlay
        loop
        muted
        style={{
            position:"absolute",
            width:"100%",
            left:"50%",
            top:"50%",
            height:"100%",
            objectFit:"cover",
            transform:"translate(-50% ,-50%)",
            zIndex:"-1"
        }}>
       <source src={v2} type="video/mp4"/>
        </video>

        
        {/* <div className="container"> */}
             <br/>
             <br/>
            <h1 className="text-center" style={{color:"white"}}>Admin Login</h1>
                    
            {/* <div className = "card col-md-6 offset-md-3 offset-md-3"> */}
                            
                        {/* <div className = "card-body"> */}
                        
                                    <form>
                                    <div className = "form-group" style={{width:"40%", marginLeft:"30%", marginTop:"3%",color:"white"}}>
                                            <label> Admin Id: </label>
                                            <input placeholder="Admin Id" name="AdminId" className="form-control" 
                                                value={this.state.AdminId} onChange={this.changeAcnoHandler}/>
                                        </div>
                                        
                                        <div className = "form-group" style={{width:"40%", marginLeft:"30%", marginTop:"3%",color:"white"}}>
                                            <label> Password: </label>
                                            <input type={this.state.x} placeholder="Password" name="pass" className="form-control" 
                                                value={this.state.pass} onChange={this.changePinHandler}
                                                />
                                                {/* <i>{eye}</i> */}
                                                <br/>
                                                <i onClick={ () => this.myFunction()}>{eye}</i>
                                                
                                        {/* <button className="btn btn-success" onClick={this.Postlogin}>Admin Login</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button> */}
                                        <Button className="btn-lg btn-success btn-block" onClick={this.Postlogin} >Admin login </Button>
                                        <Button className="btn-lg btn-danger btn-block" onClick={this.cancel.bind(this)} >Cancel </Button>
                                        </div>
                                        <h3 className="text-warning">
                                            {
                                                this.getTitle()
                                            }
                                        </h3>
                                        

                                        {/* <button className="btn btn-success" onClick={this.Postlogin}>Admin Login</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button> */}
                                    </form>
                                    
                                </div>
                                //  </div>
                                 
    //   </div>
        //  </div>
    )
   }
   
}








