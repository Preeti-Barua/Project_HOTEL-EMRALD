// import React from 'react';
// import {Carousel} from 'react-bootstrap'; 
// import 'bootstrap/dist/css/bootstrap.min.css';
// import img1 from './room1.jpeg';
// import img2 from './room2.jpeg';
// import img3 from './room3.jpeg';
// import img4 from './room4.jpeg';
// import img5 from './room5.jpeg';
// import img6 from './room6.jpeg';
// import img7 from './room7.jpeg';


// function Imageslider()
// {
//     return(
//         <div>
//             <hr/>
//             <Carousel interval={1400}>
//             <Carousel.Item>
//                 <img src={img1} height="600px" width="1550px" alt="img1"/>
//             </Carousel.Item>
//             <Carousel.Item>
//                 <img src={img2} height="600px" width="1550px" alt="img2"/>
//             </Carousel.Item>
//             <Carousel.Item>
//                 <img src={img3} height="600px" width="1550px" alt="img3"/>
//             </Carousel.Item>
//             <Carousel.Item>
//                 <img src={img4} height="600px" width="1550px" alt="img4"/>
//             </Carousel.Item>
//             <Carousel.Item>
//                 <img src={img5} height="600px" width="1550px" alt="img5"/>
//             </Carousel.Item>
//             <Carousel.Item>
//                 <img src={img6} height="600px" width="1550px" alt="img6"/>
//             </Carousel.Item>
//             <Carousel.Item>
//                 <img src={img7} height="600px" width="1550px" alt="img7"/>
//             </Carousel.Item>
//             </Carousel>    
//         </div>
//     );
// }

// export default Imageslider;


import React from 'react';
import {Carousel} from 'react-bootstrap'; 
import 'bootstrap/dist/css/bootstrap.min.css';


import img1 from './room11.jpeg';
import img2 from './p4.jpg';
import img3 from './room10.jpeg';
import img4 from './p1.jpg';
import img5 from './room12.jpeg';

function Imageslider()
{
    return(
        <div>
           
            <Carousel interval={1400}>
            <Carousel.Item>
                <img src={img1} height="600px" width="1550px" alt="img1"/>
                <div class="carousel-caption d-none d-md-block" >
        <h3>Presidential Suite.</h3>
        </div>
            </Carousel.Item>
            <Carousel.Item>
                <img src={img2} height="600px" width="1550px" alt="img2"/>
                <div class="carousel-caption d-none d-md-block">
                 <h3>Lawn Dining</h3></div>
            </Carousel.Item>
            <Carousel.Item>
                <img src={img3} height="600px" width="1550px" alt="img3"/>
        </Carousel.Item>
            <Carousel.Item>
                <img src={img4} height="600px" width="1550px" alt="img4"/>
                <div class="carousel-caption d-none d-md-block">
             <h3>Emrald Restaurant</h3></div>
            </Carousel.Item>
            <Carousel.Item>
                <img src={img5} height="600px" width="1550px" alt="img5"/>
                <div class="carousel-caption d-none d-md-block">
                 <h3>Double Economy</h3></div>
            </Carousel.Item>
         
            </Carousel>  
              
        </div>
    );
}

export default Imageslider;