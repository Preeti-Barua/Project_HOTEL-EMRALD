import React, { Component } from 'react'
import { Redirect } from 'react-router';
import EmployeeService from '../service/EmployeeService'
import Logout from './LogoutAdmin';

export default class UpdateEmployeeComponent extends Component {
    constructor(props){
        super(props) 

        const token=localStorage.getItem("token");

        let loggedin=true;

        if(token==null)
        {
            loggedin=false;
        }

        this.state={
            empid: this.props.match.params.id,
            govtid:' ',
            name:' ',
            occupation:' ',
            gender:' ',
            permanent_address:' ',
            temporary_address:' ',
            dateofbirth:' ',
            localrefrence:' ',
            phoneno:' ',
            status: ' ',

            st:'',
            loggedin
        


        }
        this.changenameHandler=this.changenameHandler.bind(this)
        this.updateEmployee=this.updateEmployee.bind(this)
    }
    componentDidMount(){
        EmployeeService.getEmployeesById(this.state.empid).then((res) =>{
            if(res.status === 200)
            {
            let employee=res.data.content;
            console.log(employee);
            this.setState({
                // empid:employee.empid,
                govtid: employee.govtid,
                name:employee.name,
                occupation: employee.occupation,
                gender:employee.gender,
                permanent_address:employee.permanent_address,
                temporary_address:employee.temporary_address,
                dateofbirth:employee.dateofbirth,
                localrefrence:employee.localrefrence,
                phoneno:employee.phoneno,
                status: employee.status
                  });
                }
                else{
                    console.log(res);
                }
            }).catch((error) => {
                console.log(error);
                this.props.history.push('/S-D-R');
            });
    }
    updateEmployee= (e) =>{
        e.preventDefault();
        let emp= {
            empid:this.state.empid,
            govtid:this.state.govtid,
            name:this.state.name,
            occupation:this.state.occupation,
            gender:this.state.gender,
            permanent_address:this.state.permanent_address,
            temporary_address:this.state.temporary_address,
            dateofbirth:this.state.dateofbirth,
            localrefrence:this.state.localrefrence,
            phoneno:this.state.phoneno,
            status:this.state.status,
            };
            console.log('employee =>' +JSON.stringify(emp));

            EmployeeService.updateEmployee(emp).then(res =>{

            if(res.status === 200)
            {
                let c=res.data;
                console.log(c);
                this.setState({st:c.status});
                if(c.status===1)
                {
                    this.props.history.push('/view-Employee');
                }
            }
            else{
                console.log(res);
            }
            }).catch((error) => {
                console.log(error);
                this.props.history.push('/S-D-R');
            });


    }
    // changeidHandler=(event)=>{
    //     this.setState({id: event.target.value});
    // }
    changegovtidHandler=(event)=>{
        this.setState({govtid: event.target.value});
    }
    changenameHandler=(event)=>{
        this.setState({name: event.target.value});
    }
    changeoccupationHandler=(event)=>{
        this.setState({occupation: event.target.value});
    }
    changegenderHandler=(event)=>{
        this.setState({gender: event.target.value});
    }
    changepermanent_addressHandler=(event)=>{
        this.setState({permanent_address: event.target.value});
    }
    changetemporary_addressHandler=(event)=>{
        this.setState({temporary_address: event.target.value});
    }

    changeDateofBirthHandler=(event)=>{
        this.setState({dateofbirth: event.target.value});
    }
   
    changelocalrefrenceHandler=(event)=>{
        this.setState({localrefrence: event.target.value});
    }

   changephonenoHandler=(event)=>{
        this.setState({phoneno: event.target.value});
    }
    changestatusHandler=(event)=>{
        this.setState({status: event.target.value});
    }


    getTitle()
    {
        if(this.state.st===0)
        {
            return <div className="text-center">Employee could not be Updated</div>
        }
    }


   
    
    cancel(){
        this.props.history.push('/view-Employee');
    }
    render() {
        if(this.state.loggedin=== false)
        {
            return <Redirect to="/Adminlogin"></Redirect>
        }
        return (
            <div>
                <br/>
                <Logout/>
                <br/>
               
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3">
                            <br/>
                        <h3 className="text-center" style={{"font-family":"elephant"}}>Update Employees</h3>
                        <div className="card-body">
                            <form>
                            {/* <div className="form-group">
                                                <label> EmployeeId</label>
                                                <input placeholder="id" name="id" className="form-control"
                                                value={this.state.id} onChange={this.changeidHandler}/>
                                            </div> */}
                                            <div className="form-group">
                                                <label>Govtid</label>
                                                <input placeholder="Govtid" name="govtid" className="form-control"
                                                value={this.state.govtid} onChange={this.changegovtidHandler}/>
                                            </div>
                                            <div className="form-group">
                                                <label>Name</label>
                                                <input placeholder="Employee Name" name="name" className="form-control"
                                                value={this.state.name} onChange={this.changenameHandler}/>
                                            </div>
                                            <div className="form-group">
                                                <label>designation</label>
                                                <input placeholder="designation" name="occupation" className="form-control"
                                                value={this.state.occupation} onChange={this.changeoccupationHandler}/>
                                            </div>
                                            <div className="form-group">
                                                <label>Gender</label>
                                                <select  value={this.state.gender} onChange={this.changegenderHandler} name="gender" className="form-control">
                                             <option value="choose">choose</option>
                                                <option value="M">Male</option>
                                                <option value="F">Female</option>
                                                <option value="O">Other</option>
                                             </select>
                                                {/* <input placeholder="'M' or 'F'" name="gender" className="form-control"
                                                value={this.state.gender} onChange={this.changegenderHandler}/> */}
                                            </div>
                                            <div className="form-group">
                                                <label>Permanent Address</label>
                                                <input placeholder="P Address" name="permanent_address" className="form-control"
                                                value={this.state.permanent_address} onChange={this.changepermanent_addressHandler}/>
                                            </div>
                                            <div className="form-group">
                                                <label>Temp address</label>
                                                <input placeholder="Temp Address" name="temporary_address" className="form-control"
                                                value={this.state.temporary_address} onChange={this.changetemporary_addressHandler}/>
                                            </div>



                                            <div className="form-group">
                                                <label>DOB</label>
                                                <input placeholder="Date-of-Birth" name="dateofbirth" className="form-control"
                                                value={this.state.dateofbirth} onChange={this.changeDateofBirthHandler}/>
                                            </div>
                                       
                                         
                                            <div className="form-group">
                                                <label>Local Refrence</label>
                                                <input placeholder="Local Refrence" name="localrefrence" className="form-control"
                                                value={this.state.localrefrence} onChange={this.changelocalrefrenceHandler}/>
                                            </div>
                                         
                                         <div className="form-group">
                                                <label>Phone</label>
                                                <input placeholder="Contact Number" name="phoneno" maxlength="10" className="form-control"
                                                value={this.state.phoneno} onChange={this.changephonenoHandler}/>
                                            </div>

                                            <div className="form-group">
                                                <label>Status</label>
                                                <select value={this.state.status} onChange={this.changestatusHandler} name="status" className="form-control">
                                             <option value="choose">choose</option>
                                                <option value="W">Working</option>
                                                <option value="NW">Non Working</option>
                                             </select>
                                                {/* <input placeholder="Status" name="status" className="form-control"
                                                value={this.state.status} onChange={this.changestatusHandler}/> */}
                                            </div>
                                            <div className="text-danger">
                                                {
                                                    this.getTitle()
                                                }
                                            </div>

                                            <button className="btn btn-success" onClick={this.updateEmployee}>update</button>
                                            <button className="btn btn-danger" onClick={this.cancel.bind(this)}style={{marginLeft:"10px"}}>Cancel</button>
                                            
                            
                            </form>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
    
