import React, { Component } from 'react'
import { Redirect } from 'react-router';
import Service from '../service/Service'
import Logout from './LogoutRec';
import MyComponent from './Searchbar';


class ViewCustomer extends Component{
    constructor(props){
        super(props)

        const token=localStorage.getItem("tokenrec");

        let loggedin=true;

        if(token==null)
        {
            loggedin=false;
        }

        this.state={
            customers: [],

            status:'',

            
            loggedin
        }
        this.addCustomer= this.addCustomer.bind(this);
        this.editCustomer=this.editCustomer.bind(this);
        this.back=this.back.bind(this);
        this.Search=this.Search.bind(this);
      
    }

    editCustomer(cid){
        this.props.history.push(`/update-Customer/${cid}`);

    }
    addCustomer(){
        this.props.history.push('/add-Customer');
    }

    // selfn= (selectedRow) => e => {
    //     if (selectedRow !== undefined) {
    //         console.log(selectedRow);
    //         this.setState({ selectedRow  });
    //       }
    //   }customer.name

    selfn= (codate,cotime)  => {

        console.log(Date.now()/(60*60*1000));
        var t1=(Date.now()/(60*60*1000));
        // console.log(t1);
        var today = new Date();
        // console.log(Date.parse(codate+' '+cotime)/(60*60*1000));
        var currentHours=today.getHours()+(today.getMinutes()/60);
        // console.log(currentHours);
       
        var a = cotime.split(':');
        var checkOutHours=(+a[0])+(+a[1]/60);
        var t2=(Date.parse(codate+' '+cotime)/(60*60*1000));
        // console.log(t2);
        // console.log(Date.parse(codate)/(60*60*1000));
        console.log((t2-t1)/(24));
            if (((t2-t1)/24) <1) {
                if(checkOutHours>currentHours && ((checkOutHours-currentHours)<2)){
                   
                    return 'yellow';
                }
                else return 'Blue';
              }
              else
              return 'green';
          }

        Search(){
             this.props.history.push('/search');
        }


        back(){
            this.props.history.push('/Reception');
        }
    // checkEmployee(){
    //     this.props.history.push('/checking');
    // }
    componentDidMount(){

        Service.getCustomers().then((res) => {
            let c=res.data;
            console.log(c);
            this.setState({status:c.status});
            if(c.status===1)
            {
                this.setState({customers: c.contlist});
            }
            

        });


     }

    getTitle()
    {
        if(this.state.status===0)
        {
            return <div className="text-center">No Customer Found !</div>
        }
    }

    render()
    {
        if(this.state.loggedin=== false)
        {
            return <Redirect to="/Receptionlogin"></Redirect>
        }
        return (
            // <div className="container">
                <div style={{marginLeft: "40px"}}>
                <br/>
                <Logout/>
                <button type="button" className="btn btn-primary" onClick={this.back} style={{marginLeft: "-10px"}} >Back</button>
           
            <button className="btn btn-warning" onClick={this.Search} style={{marginLeft: "80px"}}> Search By Name</button> 

                <h1 className="text-center" style={{"color":"white","font-family":"elephant"}}> Customers List</h1>
                <div className="text-danger">
                        {
                            this.getTitle()
                        }
                    </div>
                    <div style={{marginRight: "40px"}} >
                <div className="row">
                    {/* <button className="btn btn-primary" onClick={this.addEmployee}> Add Employee </button> */}
                    {/* <div className="text-center"> */}
                    <table className="table table-bordered"  style={{"borderWidth":"3px", 'borderColor':"black", 'borderStyle':'solid'}}> 
                
                        <thead style={{'background-color': 'Navy',"border":"3px solid black","color":"white"}}>
                           
                            <tr>
                                {/* <th>Id</th> */}
                                <th>GovtId</th>
                                <th>CustomerName</th>
                                <th>Gender</th>
                                <th>PhoneNo</th>
                                <th>Address</th>
                                {/* <th>Pincode</th> */}
                                <th>RoomNo</th>
                                <th>CheckInDate </th>
                                <th>CheckInTime</th>
                                <th >CheckOutDate </th>
                                <th>CheckOutTime</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody style={{'border':"3px solid black"}}>
                            {
                                this.state.customers.map(
                                    customer =>
                                    // <tr key={customer.customerid} style={{'background-color': 'seashell',"border":"2px solid black" }} onClick={this.selfn(customer.customerid)} className={this.state.selectedRow === customer.customerid ? "tableSelected" : "" } >
                                    //  <tr key={customer.customerid} style={{'background-color': 'seashell',"border":"2px solid black" }} onClick={this.selfn(customer.customerid)} className={this.state.selectedRow === customer.customerid ? "tableSelected" : ""? "tableHover":""} >
                                         <tr key={customer.customerid} style={{"color":"white","border":"2px solid black" }} className={this.selfn(customer.checkoutdate,customer.checkouttime)}  >
                                         {/* <td>{customer.customerid}</td> */}
                                        <td>{customer.govtid}</td>
                                        <td>{customer.name}</td>
                                          <td>{customer.gender}</td>
                                          <td>{customer.phone_no}</td>
                                          <td>{customer.city_address}</td>
                                          {/* <td>{customer.pincode}</td> */}
                                          <td>{customer.roomno}</td>
                                          <td>{customer.checkindate}</td>
                                          <td>{customer.checkintime}</td>
                                          <td>{customer.checkoutdate}</td>
                                          <td>{customer.checkouttime}</td>
                                          <td>
                                              {/* <button onClick= { () =>this.editCustomer(customer.customerid)}className="btn btn-info">Update</button> */}
                                              <img onClick= { () =>this.editCustomer(customer.customerid)} src="../../../images/update.jpg" style={{"width":"25%"}}></img>
 
                                          </td>
                                          </tr>         
                                )
                            }
                        </tbody>
                            
                    </table>
                    </div>
                    </div>
            </div>
            // </div>
        )
    }
}
export default ViewCustomer;
