import React, { Component } from 'react'
import { Redirect } from 'react-router';
import RoomService from '../service/RoomService'
import Logout from './LogoutRec';

class ShowRooms extends Component{
    constructor(props){
        super(props)

        const token=localStorage.getItem("tokenrec");

        let loggedin=true;

        if(token==null)
        {
            loggedin=false;
        }

        this.state={
            rooms: [],
            
            loggedin

        }
        
        
        this.book= this.book.bind(this);
        this.updateRoombyAdmin=this.updateRoombyReceptionist.bind(this);
        this.unBbook=this.unBbook.bind(this);
        this.back=this.back.bind(this);
        // this.deleteRoombyAdmin=this.deleteRoombyAdmin.bind(this);
      
    }
    updateRoombyReceptionist(roomno){
        this.props.history.push(`/update-roominfo/${roomno}`);

    }
    book(roomno,bookstatus){
        console.log(bookstatus);
        if(bookstatus==="Booked")
        {
            alert("Room is Already Booked");
        }
        else{
            this.props.history.push(`/add-Customer/${roomno}`);
        }
        

    }
    unBbook(roomno,bookstatus){
        if(bookstatus==="UnBooked")
        {
            alert("Room is Already UnBooked");
        }
        else
        {
            RoomService.unBbooking(roomno).then(res =>{
            let c=res.data;
            if(c.status===1)
            {
                this.props.history.push('/show-rooms');
            }
            window.location.reload();
        
            });
        }
    }
   
    back(){
        this.props.history.push('/Reception');
    }
    // checkEmployee(){
    //     this.props.history.push('/checking');
    // }
    componentDidMount(){

        RoomService.getRooms().then((res) => {

            this.setState({rooms: res.data});
            console.log(res.data);
            
        });


     }
    render()
    {
        if(this.state.loggedin=== false)
        {
            return <Redirect to="/Receptionlogin"></Redirect>
        }
        return (
            <div>
                <br/>
            <Logout/>
            <button type="button" className="btn btn-primary" onClick={this.back} style={{marginLeft: "110px"}} >Back</button>
            <div  className="container" style={{backgroundImage: "url(/image.png)"}}>
                 
                <h1 className="text-center" style={{"font-family":"elephant","fontSize":"40px", "color":"white"}}> Rooms List</h1>
                <div className="row">
                    
                    {/* <div className="text-center"> */}
                    <table className="table table-striped table-bordered" style={{"borderWidth":"5px", 'borderColor':"black", 'borderStyle':'solid'}}  > 
 
                
                        <thead style={{'background-color': 'Navy',"border":"3px solid black","font-family":"arial black","color":"white"}}>
                       
                           
                            <tr>
                                 <th >Room no </th>
                                <th>Room type(bed)</th>
                                <th>Booking status</th>
                                <th>Cleaning status </th>
                                <th>Action</th>
                                
                             
                            </tr>
                        </thead>
                        <tbody style={{'border':"3px solid black"}}>
                            {
                                this.state.rooms.map(
                                    Rooms =>
                                    <tr key={Rooms.roomno} style={{'background-color': 'seashell',"border":"2px solid black", "font-family":"verdana" }}>
                                        <td>{Rooms.roomno}</td>
                                         <td>{Rooms.room_type}</td>
                                        <td>{Rooms.booking_status}</td>
                                        <td>{Rooms.cleaning_status}</td>
                                        
                                        <td>
                                            <button onClick= { () =>this.updateRoombyReceptionist(Rooms.roomno)} onup className="btn btn-info">Update</button>
                                         
                                            <button onClick= { () =>this.book(Rooms.roomno,Rooms.booking_status)}className="btn btn-warning"  >Book</button>
                                            
                                            <button onClick= { () =>this.unBbook(Rooms.roomno,Rooms.booking_status)}className="btn btn-outline-danger">UnBook</button>
                                        </td>
                                    </tr>         
                                )
                            }
                        </tbody>
                        
                    </table>
                    </div>

                </div>
             </div>
        )
    }
}
export default ShowRooms;