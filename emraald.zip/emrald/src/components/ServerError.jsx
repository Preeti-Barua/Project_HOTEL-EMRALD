import { Component } from "react"

export default class ServerErrorPage extends Component {

    
    

    
    render() {
    return (
    
        <div className="text-center">
        <div className="mt-5" >
             <h1>Server Did Not Respond !</h1>
        </div>
        </div>
    )
   }
   
}